// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Download",
      "filePrefix": "study",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -250,
          "angle": 0,
          "width": 216.64,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Instructions",
          "fontStyle": "normal",
          "fontWeight": "bold",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 0,
          "top": -200,
          "angle": 0,
          "width": 816.58,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Welcome to our Temporal Discounting Experiment!",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 0,
          "top": 125,
          "angle": 0,
          "width": 882.49,
          "height": 539.51,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "\nThis screen is followed by a brief survey. \nWe encourage you to fill it in as accurately as possible.\n\nThe survey is followed by 72 trials. In each trial, \nyou will be presented a choice between $20 now, and\nan amount at a delayed time. \nFurther instructions are provided before the trials!\n\nPress Enter to Continue\n\n\n",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 13,
          "top": 25,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 0,
          "top": 200,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Enter)": "Finished Instructions 1"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Screen",
      "timeout": "1200000"
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cmain\u003E\n  \u003Cform\u003E\n    \u003Cdiv  style = \"float:left\"\u003E\n      \u003Cdiv\u003E\n        \u003Cp\u003EIdentifier (name\u002Fusername\u002Ffaceroll)\u003C\u002Fp\u003E\n        \u003Cinput type = \"text\", name = \"ID\"\u003E\n      \u003C\u002Fdiv\u003E\n      \u003Cdiv\u003E\n        \u003Cp\u003EAge\u003C\u002Fp\u003E\n        \u003Cinput type = \"number\", name = \"Age\", min = 17\u003E\n      \u003C\u002Fdiv\u003E\n    \u003Cdiv\u003E\n      \u003Cp\u003EWhat is your current level of study?\u003C\u002Fp\u003E\n      \u003Cselect name = \"Degree\"\u003E\n        \u003Coption value = \"Undergraduate\"\u003EUndergrad\u003C\u002Foption\u003E\n        \u003Coption value = \"Masters\"\u003EMasters\u003C\u002Foption\u003E\n        \u003Coption value = \"PhD\"\u003EPhD\u003C\u002Foption\u003E\n        \u003Coption value = \"Postdoc\"\u003EPostdoc\u003C\u002Foption\u003E\n      \u003C\u002Fselect\u003E\n    \u003C\u002Fdiv\u003E\n    \u003C\u002Fdiv\u003E\n    \u003Cdiv  style = \"position: absolute; margin-left: 35%\"\u003E\n      \u003Cdiv\u003E\n        \u003Cp\u003ERoughly what \u003Cb\u003Epercentage\u003C\u002Fb\u003E of your monthly expenses are on:\u003C\u002Fp\u003E\n        \u003Cp\u003E Essentials (Rent, Food, Tech etc.) \u003C\u002Fp\u003E \n        \u003Cinput type = \"text\", name = \"Essentials\"\u003E\n        \u003Cp\u003E Leisure (Outings, Movies, Books, etc.) \u003C\u002Fp\u003E \n        \u003Cinput type = \"text\", name = \"Leisure\"\u003E\n        \u003Cp\u003E Investments (Savings, Bonds, Crypto, etc.) \u003C\u002Fp\u003E \n        \u003Cinput type = \"text\", name = \"Investments\"\u003E\n      \u003C\u002Fdiv\u003E\n    \u003C\u002Fdiv\u003E\n    \u003Cdiv style = \"float: right\"\u003E\n    \u003Cp\u003EOn a scale of 1-6 (6: breaking down\u002Fon the verge) \u003Cbr\u003EHow stressed are you feeling?\u003C\u002Fp\u003E\n      \u003Cinput type = \"number\", name = \"Stress\", min = 0, max = 6\u003E\n    \u003Cp\u003EOn a scale of 1-6 (6: dreams are coming true!) \u003Cbr\u003EHow happy are you feeling today?\u003C\u002Fp\u003E\n      \u003Cinput type = \"number\", name = \"Happiness\", min = 0, max = 6\u003E \n    \u003Cp\u003EHow many hours of sleep did you get last night?\u003C\u002Fp\u003E\n      \u003Cinput type = \"number\", name = \"Sleep\", min = 0, max = 48\u003E \n    \u003C\u002Fdiv\u003E\n    \u003C\u002Fbr\u003E\n    \u003Cbutton style = \"position: absolute; margin-top: 30%;\", type=\"submit\"\u003ESubmit\u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E\n",
      "scrollTop": true,
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Form",
      "timeout": "1200000"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -275,
          "angle": 0,
          "width": 216.64,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Instructions",
          "fontStyle": "normal",
          "fontWeight": "bold",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -240,
          "angle": 0,
          "width": 508.71,
          "height": 78.11,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "\nEach screen will show 2 options",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -164,
          "angle": 0,
          "width": 611.37,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Option 1 is always the same: $20 now",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 10,
          "top": -50,
          "angle": 0,
          "width": 633.8,
          "height": 120.05,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Press the '1' key to select $20 now, \nOR\n'2' key to select the displayed alternate",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 0,
          "top": 150,
          "angle": 0,
          "width": 913.64,
          "height": 203.94,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "You have 10 seconds to make a choice\nThere is a half second gap between trials,\nand a fixation cross for 1 second at the start of each trial\n\nPress Enter when you're ready to begin! ",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Enter)": "Finished Instructions 2"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Screen",
      "timeout": "1200000"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "Amount": 25,
          "Delay": "1 week"
        },
        {
          "Amount": 25,
          "Delay": "2 weeks"
        },
        {
          "Amount": 25,
          "Delay": "1 month"
        },
        {
          "Amount": 25,
          "Delay": "3 months"
        },
        {
          "Amount": 25,
          "Delay": "6 months"
        },
        {
          "Amount": 25,
          "Delay": "1 year"
        },
        {
          "Amount": 30,
          "Delay": "1 week"
        },
        {
          "Amount": 30,
          "Delay": "2 weeks"
        },
        {
          "Amount": 30,
          "Delay": "1 month"
        },
        {
          "Amount": 30,
          "Delay": "3 months"
        },
        {
          "Amount": 30,
          "Delay": "6 months"
        },
        {
          "Amount": 30,
          "Delay": "1 year"
        },
        {
          "Amount": 50,
          "Delay": "1 week"
        },
        {
          "Amount": 50,
          "Delay": "2 weeks"
        },
        {
          "Amount": 50,
          "Delay": "1 month"
        },
        {
          "Amount": 50,
          "Delay": "3 months"
        },
        {
          "Amount": 50,
          "Delay": "6 months"
        },
        {
          "Amount": 50,
          "Delay": "1 year"
        },
        {
          "Amount": 65,
          "Delay": "1 week"
        },
        {
          "Amount": 65,
          "Delay": "2 weeks"
        },
        {
          "Amount": 65,
          "Delay": "1 month"
        },
        {
          "Amount": 65,
          "Delay": "3 months"
        },
        {
          "Amount": 65,
          "Delay": "6 months"
        },
        {
          "Amount": 65,
          "Delay": "1 year"
        },
        {
          "Amount": 80,
          "Delay": "1 week"
        },
        {
          "Amount": 80,
          "Delay": "2 weeks"
        },
        {
          "Amount": 80,
          "Delay": "1 month"
        },
        {
          "Amount": 80,
          "Delay": "3 months"
        },
        {
          "Amount": 80,
          "Delay": "6 months"
        },
        {
          "Amount": 80,
          "Delay": "1 year"
        },
        {
          "Amount": 130,
          "Delay": "1 week"
        },
        {
          "Amount": 130,
          "Delay": "2 weeks"
        },
        {
          "Amount": 130,
          "Delay": "1 month"
        },
        {
          "Amount": 130,
          "Delay": "3 months"
        },
        {
          "Amount": 130,
          "Delay": "6 months"
        },
        {
          "Amount": 130,
          "Delay": "1 year"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Trial",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "rect",
                "left": "0",
                "top": "0",
                "angle": 0,
                "width": "200",
                "height": "20",
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black"
              },
              {
                "type": "rect",
                "left": "0",
                "top": "0",
                "angle": 90,
                "width": "200",
                "height": "20",
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Fixation Cross",
            "timeout": "1000"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 841.82,
                "height": 203.94,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "1. $20 now\n\nOR\n\n2. $${parameters.Amount} in ${parameters.Delay}",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "keypress(1)": "0",
              "keypress(2)": "1",
              "keypress(uparrow)": "0"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Choice",
            "timeout": "10000"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Inter-Stimulus",
            "timeout": "500"
          }
        ]
      }
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -250,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -50,
          "angle": 0,
          "width": 332.27,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "You're halfway through!",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 14,
          "top": -100,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 11,
          "top": -25,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": 150,
          "angle": 0,
          "width": 348.63,
          "height": 120.05,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "\n\nPress Enter to Continue ",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Enter)": "Finished Instructions 3"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Screen",
      "timeout": "120000"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "Amount": 25,
          "Delay": "1 week"
        },
        {
          "Amount": 25,
          "Delay": "2 weeks"
        },
        {
          "Amount": 25,
          "Delay": "1 month"
        },
        {
          "Amount": 25,
          "Delay": "3 months"
        },
        {
          "Amount": 25,
          "Delay": "6 months"
        },
        {
          "Amount": 25,
          "Delay": "1 year"
        },
        {
          "Amount": 30,
          "Delay": "1 week"
        },
        {
          "Amount": 30,
          "Delay": "2 weeks"
        },
        {
          "Amount": 30,
          "Delay": "1 month"
        },
        {
          "Amount": 30,
          "Delay": "3 months"
        },
        {
          "Amount": 30,
          "Delay": "6 months"
        },
        {
          "Amount": 30,
          "Delay": "1 year"
        },
        {
          "Amount": 50,
          "Delay": "1 week"
        },
        {
          "Amount": 50,
          "Delay": "2 weeks"
        },
        {
          "Amount": 50,
          "Delay": "1 month"
        },
        {
          "Amount": 50,
          "Delay": "3 months"
        },
        {
          "Amount": 50,
          "Delay": "6 months"
        },
        {
          "Amount": 50,
          "Delay": "1 year"
        },
        {
          "Amount": 65,
          "Delay": "1 week"
        },
        {
          "Amount": 65,
          "Delay": "2 weeks"
        },
        {
          "Amount": 65,
          "Delay": "1 month"
        },
        {
          "Amount": 65,
          "Delay": "3 months"
        },
        {
          "Amount": 65,
          "Delay": "6 months"
        },
        {
          "Amount": 65,
          "Delay": "1 year"
        },
        {
          "Amount": 80,
          "Delay": "1 week"
        },
        {
          "Amount": 80,
          "Delay": "2 weeks"
        },
        {
          "Amount": 80,
          "Delay": "1 month"
        },
        {
          "Amount": 80,
          "Delay": "3 months"
        },
        {
          "Amount": 80,
          "Delay": "6 months"
        },
        {
          "Amount": 80,
          "Delay": "1 year"
        },
        {
          "Amount": 130,
          "Delay": "1 week"
        },
        {
          "Amount": 130,
          "Delay": "2 weeks"
        },
        {
          "Amount": 130,
          "Delay": "1 month"
        },
        {
          "Amount": 130,
          "Delay": "3 months"
        },
        {
          "Amount": 130,
          "Delay": "6 months"
        },
        {
          "Amount": 130,
          "Delay": "1 year"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Trial",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "rect",
                "left": "0",
                "top": "0",
                "angle": 0,
                "width": "200",
                "height": "20",
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black"
              },
              {
                "type": "rect",
                "left": 0,
                "top": "0",
                "angle": 90,
                "width": "200",
                "height": "20",
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Fixation Cross",
            "timeout": "1000"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 841.82,
                "height": 203.94,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "1. $20 now\n\nOR\n\n2. $${parameters.Amount} in ${parameters.Delay}",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "keypress(1)": "0",
              "keypress(2)": "1"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Choice",
            "timeout": "10000"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Inter-Stimulus",
            "timeout": "500"
          }
        ]
      }
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -250,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -50,
          "angle": 0,
          "width": 129.84,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "All Done!",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 14,
          "top": -100,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 11,
          "top": -25,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": 150,
          "angle": 0,
          "width": 756.03,
          "height": 203.94,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "\n\nPress Enter to Continue\nPlease download your data from the link at the end of\nprogram and send it across to us! ",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Enter)": "Finished Instructions 3"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Screen",
      "timeout": "120000"
    }
  ]
})

// Let's go!
study.run()